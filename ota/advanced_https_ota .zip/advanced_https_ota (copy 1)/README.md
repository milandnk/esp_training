| Supported Targets | ESP32 | ESP32-C2 | ESP32-C3 | ESP32-C5 | ESP32-C6 | ESP32-P4 | ESP32-S2 | ESP32-S3 |
| ----------------- | ----- | -------- | -------- | -------- | -------- | -------- | -------- | -------- |

# Advanced HTTPS OTA example

This example is based on `esp_https_ota` component's APIs.

## Configuration

Refer README.md in the parent directory for setup details
first:build flash monitor first code + wifi cred+create server (python3 -m http.server 8000 --bind 0.0.0.0)
code update and build flash monitor
which dir server open there new bin file set